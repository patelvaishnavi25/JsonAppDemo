//
//  common.swift
//  jsonappdemo
//
//  Created by TOPS on 7/13/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class common: NSObject {
    
    func getjson(url:String) -> [String:Any] {
        let url = URL(string: url);
        
        do {
            let dt = try Data(contentsOf: url!)
            
            do {
                let jsondata = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any];
                
                return jsondata;
                
            } catch  {
             
                return [:];
            }
            
        } catch  {
            
            return [:];
            
        }
        
        
        
    }

}
