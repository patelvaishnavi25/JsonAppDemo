//
//  TableViewCell1.swift
//  jsonappdemo
//
//  Created by TOPS on 7/13/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class TableViewCell1: UITableViewCell {
    
    @IBOutlet weak var lbldis: UILabel!

    @IBOutlet weak var lblstname: UILabel!
    
    @IBOutlet weak var lblstatus: UILabel!
    
    @IBOutlet weak var lblarrival: UILabel!
    
    @IBOutlet weak var lbldep: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
