//
//  ViewController.swift
//  jsonappdemo
//
//  Created by TOPS on 7/13/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var cmd = common();
    
    var finalarr = [Any]();

    @IBOutlet weak var lblstname: UILabel!
    
    @IBOutlet weak var lblpos: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let jsondata = cmd.getjson(url: "https://api.railwayapi.com/v2/live/train/19033/date/13-07-2018/apikey/hft0l2w35p/");
        
        let currentstation = jsondata["current_station"] as! [String:Any];
        
        lblstname.text = "current_station\(currentstation["name"] as! String )";
        
        lblpos.text = jsondata["position"] as? String;
        
        finalarr = jsondata["route"] as! [[String:Any]];
        
        print(finalarr);
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let  cell = tableView.dequeueReusableCell(withIdentifier: "next", for: indexPath) as! TableViewCell1;
        
        let dic = finalarr[indexPath.row] as! [String:Any];
        
        let stname = dic["station"] as! [String:Any];
        
        cell.lblstname.text = stname["name"] as? String;
        
        cell.lblstatus.text = dic["status"] as? String;
        
        cell.lblarrival.text = dic["actarr"] as? String;
        
        cell.lbldep.text = dic["schdep"] as? String;
        
        
        return cell;
        
  
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

